# City Pistol Shooter

## Run locally

1. `cd server && npm install && node index.js`
2. Open `public/index.html` in browser

## Production build ready